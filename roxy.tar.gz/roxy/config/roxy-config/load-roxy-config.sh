#!/bin/bash

# this script assumes consul server is up and ready at CONSUL_SERVER_HOST:CONSUL_SERVER_PORT (leader elected, quorum reached, etc)

readonly ROXY_PROPERTIES_FILE="/opt/roxy/init/roxy.properties"
readonly ROXY_RULES_DIR="/opt/roxy/rules"
readonly CONSUL_KEY_VALUE_PREFIX="http://$ROXY_CONSUL_SERVER_HOST_IP:$ROXY_CONSUL_SERVER_HOST_PORT/v1/kv/roxy/$ROXY_APP_NAME/"
readonly CONSUL_RULES_PREFIX="rules/"
readonly CONSUL_RULES_ORDER_KEY="rules-order"
readonly DEFAULT_UPSTREAM_BACKEND_KEY="nginx/upstream/default"

function add_to_consul() {

  key=$1
  value=$2

  # check if key already exists in consul
  # if not, write to consul
  # if yes, skip so the existing value is not overwritten

  printf "\n[$key] checking in consul...\n"

  curl -sf $CONSUL_KEY_VALUE_PREFIX$key
  if [[ $? -ne 0 ]] ; then

    printf "\n[$key] not found in consul; adding\n"

    # save key and value
    # printf "value right before saving is $value"
    curl -s -X PUT -d "$value" "$CONSUL_KEY_VALUE_PREFIX$key" > /dev/null
    if [[ $? -eq 0 ]] ; then
        printf "\n[$key] added with value [$value]\n";
    else
        printf "\n[$key] not added to consul\n";
    fi
  else
    # key already exists in consul, skip
    printf "\n[$key] found in consul, skipping\n"
  fi
}

function load_properties () {

  while read -r line; do

      [[ "$line" =~ ^#.*$ ]] && continue

      OLDIFS=$IFS

      # split the line by "=", then split the right side by " :default " to get the default value for environment property, if any
      IFS="=" read key env_variable_and_default <<< "$line"
      # printf "\nkey $key env_variable_and_default $env_variable_and_default"

      delim=" :default "
      env_variable="${env_variable_and_default%%$delim*}"
      default="${env_variable_and_default#*$delim}"

      value=${!env_variable-$default}
      printf "\n[$key] value is $value"

      add_to_consul "$key" "$value"

      IFS=$OLDIFS

  done <  "$1"  # first parameter should be the property file name
}

function load_rules () {

  RULES="$ROXY_RULES_DIR/*.lua"

  #iterate through all *.lua files in $ROXY_RULES_DIR and load them
  for file in $ROXY_RULES_DIR/*.lua; do

      printf "\nfile is $file"

      filename="${file##*/}"
      rule_name="${filename%.*}"
      printf "\nrule name is $rule_name"

      if [[ -e $file ]]; then
        rule=$(<"$file")

        add_to_consul "$CONSUL_RULES_PREFIX$rule_name" "$rule"

      else

       # if file with rule doesn't exist, don't do anything
        printf "\nno file with rule found in location $file"
      fi    
  done
}

: "${ROXY_APP_NAME:?env variable ROXY_APP_NAME needs to be set}"
: "${ROXY_CONSUL_SERVER_HOST_IP:?env variable ROXY_CONSUL_SERVER_HOST_IP needs to be set}"
: "${ROXY_CONSUL_SERVER_HOST_PORT:?env variable ROXY_CONSUL_SERVER_HOST_PORT needs to be set}"
: "${ROXY_CONSUL_CLIENT_ADVERTISE_IP:?env variable ROXY_CONSUL_CLIENT_ADVERTISE_IP needs to be set}"
: "${DEFAULT_UPSTREAM_BACKEND:?env variable DEFAULT_UPSTREAM_BACKEND needs to be set}"

printf "loading to CONSUL on $ROXY_CONSUL_SERVER_HOST_IP:$ROXY_CONSUL_SERVER_HOST_PORT"

load_properties $ROXY_PROPERTIES_FILE

# load rules iff rule directory has been provided
# if [ -z "$ROXY_RULES_DIR" ]; then
#   printf "\nnot loading rules > rules directory not provided"
# else
#   printf "\nloading rules"
#   load_rules
# fi  

# add rules-order key even if it's empty because roxy looks for it on startup
# add rules/ folder where the rules will go
# add upstream/ folder where upstream servers will go
add_to_consul "$CONSUL_RULES_ORDER_KEY" "$ROXY_RULES_ORDER"
add_to_consul "$CONSUL_RULES_PREFIX" ""
add_to_consul "$DEFAULT_UPSTREAM_BACKEND_KEY" "server $DEFAULT_UPSTREAM_BACKEND;"
