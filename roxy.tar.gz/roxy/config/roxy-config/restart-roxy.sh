#!/bin/bash

printf "\nRESTARTING ROXY"

cd /opt/roxy/nginx && lapis build production