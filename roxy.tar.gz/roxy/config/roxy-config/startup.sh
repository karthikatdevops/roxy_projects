#!/bin/bash

# generate consul watch files & register roxy as a service

rules_order_key="/roxy/$ROXY_APP_NAME/rules-order"
upstream_prefix="/roxy/$ROXY_APP_NAME/nginx/upstream/"

cd /etc/consul.d/

rm rules-order-watch.json
rm upstream-watch.json
rm roxy.json

printf '{"watches": [ {"type": "key", "key":"%s","handler":"/opt/roxy/init/restart-roxy.sh"}]}' "$rules_order_key" > rules-order-watch.json
printf '{"watches": [ {"type": "keyprefix","prefix":"%s","handler": "/opt/roxy/init/restart-roxy.sh"}]}' "$upstream_prefix" > upstream-watch.json
printf '{"service": {"name":"roxy", "address":"127.0.0.1", "port":%s, "enableTagOverride":false, "check":{"http":"http://127.0.0.1:%s", "interval":"10s"}}}' "$NGINX_LISTEN_PORT" "$NGINX_LISTEN_PORT" > roxy.json

. /opt/roxy/init/load-roxy-config.sh

/usr/bin/supervisord