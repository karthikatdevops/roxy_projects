-- sample config.lua file if not using consul-template to generate it

local config = require("lapis.config")

config("production", {
  
    --memcached = {
        --host = "127.0.0.1",
        --port = 11211
    --},

    consul = {
        host = "127.0.0.1",
        port = "8500",
        ars_rules_prefix = "/kv/roxy/ars/rules/",
        ars_rules_order_key = "/kv/roxy/ars/rules_priority"    
    }
}