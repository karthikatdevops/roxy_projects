#!/bin/bash

echo -e 'set one-12345 0 0 21\r\ndemo-one-server-group\r' | nc 10.251.17.150 11211
echo -e 'set two-abcde 0 0 21\r\ndemo-two-server-group\r' | nc 10.251.17.150 11211
echo -e 'set 1.7 0 0 21\r\ndemo-one-server-group\r' | nc 10.251.17.150 11211
