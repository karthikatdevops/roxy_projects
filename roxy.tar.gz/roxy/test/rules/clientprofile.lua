return function()
    ngx_req.read_body()

    local body, err = ngx_req.get_body_data()
    if not body then
        print("failed to get request post body: ", err)
        return
    end

    decoded_body = cjson.decode(body)

    local client_profile = decoded_body.resolveAvailability.clientProfile
    if not client_profile then
        print("clientProfile NOT FOUND")
        return
    end

    print("client_profile is " .. client_profile)

    local memc = cache.get_memcached()
    return memc:get(string_lower(client_profile))
end