return function()
    local args = ngx_req.get_uri_args()

    for key, val in pairs(args) do
        if key == "schema" and val == "1.7" then

            print("found a schema parameter with value " .. val)
            local memc = cache.get_memcached()
            return memc:get(string_lower(val))
        else
            print("parameter schema=1.7 NOT FOUND")
            return
        end
    end
end