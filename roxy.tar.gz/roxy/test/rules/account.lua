return function()
    ngx_req.read_body()

    local body, err = ngx_req.get_body_data()
    if not body then
        print("failed to get request post body: ", err)
        return
    end

    decoded_body = cjson.decode(body)

    local account = decoded_body.resolveAvailability.account
    if not account then
        print("account NOT FOUND")
    end

    print("account is " .. account)

    local memc = cache.get_memcached()
    return memc:get(string_lower(account))
end