local rules_engine = require("rules-engine")
local memc = require("roxy-memcached")

local ngx = ngx
local ngx_req = ngx.req
local string_lower = string.lower 

local _M = {}

local function create_context() 

    local context = {}
    context.ngx = ngx
    context.cjson = cjson
    context.cache = memc
    context.print = print
    context.ngx_req = ngx_req
    context.string_lower = string_lower
    context.pairs = pairs 

    return context
end

function _M.get_upstream()
    return rules_engine.route_to(create_context())
end

return _M