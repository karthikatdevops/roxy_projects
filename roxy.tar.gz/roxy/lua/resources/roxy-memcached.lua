local config = require("lapis.config").get()
local memcached = require("resty.memcached")
local utils = require("utils")

local memcached_down = nil

local connect_memcached
connect_memcached = function()
    local memcached_config = config.memcached
    if not (memcached_config) then
        return nil, "memcached not configured"
    end

    local memc, err = memcached:new()
    if not memc then
        utils.warn("failed to instantiate memcache: ", err)
        return
    end

    local ok, err = memc:connect(memcached_config.host, memcached_config.port)
    if ok then
        utils.warn("\nconnected to memcached\n")
        return memc
    else
        memcached_down = ngx.time()
        return ok, err
    end
end

local get_memcached
get_memcached = function()
    if not (memcached) then
        return nil, "missing memcached library"
    end

    if memcached_down and memcached_down + 60 > ngx.time() then
        return nil, "memcached down"
    end

    local memc = ngx.ctx.memcached
    if not (memc) then
        local after_dispatch
        do
            local _obj_0 = require("lapis.nginx.context")
            after_dispatch = _obj_0.after_dispatch
        end

        local err
        memc, err = connect_memcached()
        if not (memc) then
            return nil, err
        end

        ngx.ctx.memcached = memc
        after_dispatch(function() 
            memc:set_keepalive()
            ngx.ctx.memcached = nil
        end)
    end

    return memc
end

return {
  get_memcached = get_memcached
}