local config = require("lapis.config").get()
local consul_config = config.consul
local resty_consul = require("resty.consul")

local memcached_down = nil

local connect_consul
connect_consul = function()
    if not (consul_config) then
        return nil, "consul not configured"
    end

    local consul, err = resty_consul:new({host=consul_config.host, port=consul_config.port})
    if not consul then
        ngx.log(ngx.ERR, "failed to instantiate consul: ", err)
        return
    else
        ngx.log(ngx.WARN, "connected to consul on " .. consul_config.host .. ":" .. consul_config.port)
        return consul
    end
end

local _CONSUL = {}

function get_consul()

    if not (resty_consul) then
        return nil, "missing consul library"
    end

    local consul = ngx.ctx.consul
    if not (consul) then

        local err
        consul, err = connect_consul()
        if not (consul) then
            return nil, err
        end

        ngx.ctx.consul = consul
    end
    return consul
end

function _CONSUL.get_value_for(key)

    ngx.log(ngx.NOTICE, "\nlooking up key \n" .. key .. "\n")

    local consul = get_consul()

    -- remove leading and trailing spaces from the key
    local key = key:match( "^%s*(.-)%s*$" )

    local result, err = consul:get_decoded(key)
    if not result then 
        ngx.log(ngx.ERR, err)
    else
        local value = result[1].Value

        if ( value == cjson.null ) then
            ngx.log(ngx.NOTICE, "\nKEY [" .. key .. "] has NO VALUE")
            return nil
        else
            ngx.log(ngx.NOTICE, "\nKEY [" .. key .. "] has VALUE [" .. tostring(value) .. "]")
            return value
        end
    end
end

function _CONSUL.get_rule(name)

    local ok, result = pcall(_CONSUL.get_value_for, consul_config.rules_prefix .. name:match( "^%s*(.-)%s*$" ))
    
    if not ok then
        print(result) -- print out error message
    else
        return result
    end
end

function _CONSUL.get_rules_order()

    local ok, result = pcall(_CONSUL.get_value_for, consul_config.rules_order_key)

    if not ok then
        print(result)
    else
        return result
    end
end

function _CONSUL.save_rule(key, value)
    save(consul_config.rules_prefix .. key:match( "^%s*(.-)%s*$" ), value)
end

function _CONSUL.save_rules_order(value)
    save(consul_config.rules_order_key, value)
end

function save(key, value)

    local consul = get_consul()

    local saved, err = consul:put(key, value)
    if not saved then
        ngx.log(ngx.ERR, err)
    end
end

return _CONSUL