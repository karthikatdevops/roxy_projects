local utils = {}

function utils.table_size(table)
    local count = 0
    for _ in pairs(table) do count = count + 1 end
    return count
end

function utils.warn(...)
    ngx.log(ngx.WARN, ...)
end

function utils.notice(...)
    ngx.log(ngx.NOTICE, ...)
end

return utils