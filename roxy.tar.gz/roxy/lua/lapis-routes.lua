
local rules_engine =  require("rules-engine")
local consul =        require("resources.roxy-consul")
local lapis =         require("lapis")

local consul_config = config.consul
local io, os = io, os

local app = lapis.Application()
app:enable("etlua")

app:get("/", function()
  return "Welcome to Lapis " .. require("lapis.version") .. " running on port " .. config.port .. " in environment " .. config._name
end)

app:get("/rules", function(self)
  return { render = "rules" }
end)

app:get("/rules-with-code", function(self)
  return { render = "rules-with-code" }
end)

app:post("/add-rule", function(self)
  order = self.params.order
  name = self.params.name
  code = self.params.code

  -- adds new rule to memory to figure out priority, complete error checking
  rules_engine.add_string_rule(name, code, order)

  -- update rules in consul here: first save the rule, then priority.
  -- updating order will trigger reload of roxy, so the newly added rule needs to exist by then.
  consul.save_rule(name, code)
  consul.save_rules_order(rules_engine.rules_in_order())

  return "app: added rule > name: " .. name .. " order: " .. order .. " rule: " .. code 
end
)

app:post("/delete-rule", function(self)
  name = self.params.name

  if not name then
    return "required parameter name missing"
  else
    deleted, err = rules_engine.delete_rule(name)
    if not deleted then
      return err
    else 
      
      print("deleting rule " .. name)

      local ok, err = consul:put(consul_config.rules_key, rules_engine.rules_in_order())
      if not ok then
        ngx.log(ngx.ERR, err)
      end

      return "deleted"
    end 
  end
end)

return app
