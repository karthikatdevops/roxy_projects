local rules_engine = {}

local rules = {}
local orders = {}
local rules_in_order = ""

local loadstring = loadstring
local assert = assert
local tonumber = tonumber
local table = table
local print = print
local ipairs = ipairs
local pairs = pairs
local string_dump = string.dump
local setfenv = setfenv
local getfenv = getfenv

--TODO: address security concerns
local function load_rule(code)
  return assert(loadstring(code), "rule is not valid")()
end

local function rule_exists_for(name)
  order = orders[name]
  if order then return true, order else return false end
end

local function is_empty(s)
  return s == nil or s == ''
end

function rules_engine.existing_rules() 
  return rules
end

function rules_engine.rules_in_order()
  return rules_in_order
end

local function generate_name_to_order(rules) 
  print("generating name-to-order")
  
  name_to_order = {}
  rules_in_order = ""

  for order, rule in ipairs(rules) do
    name_to_order[rule.name] = order

    if is_empty(rules_in_order) then rules_in_order = rule.name else rules_in_order = rules_in_order .. "," .. rule.name end

    print(rule.name .. " > " .. order)
    print("\n\ncurrent rules list > " .. rules_in_order .. "\n\n")
  end
  
  return name_to_order
end

function rules_engine.delete_rule(name)
  rule_exists, order = rule_exists_for(name)
  if rule_exists then
    table.remove(rules, order)
    orders = generate_name_to_order(rules)
    return true
  else
    err = "cannot delete rule " .. name .. " because it does not exist"
    return false, err
  end
end

function rules_engine.add_string_rule(name, code, order)
    loaded_rule = load_rule(code)
    rules_engine.add_rule(name, loaded_rule, order)
end


function rules_engine.add_rule (name, loaded_rule, order)
  rule = {}
  rule["name"] = name
  rule["code"] = loaded_rule

  rule_exists, current_order = rule_exists_for(name)
  if rule_exists then
    --print("rule with this name exists, overwriting")
    removed_rule = table.remove(rules, current_order) 
    --print("removed rule " .. removed_rule.name  .. " with priority " .. order)
  end

  --[[
  invalid order is
    > non-numeric or 
    > zero/negative or
    > bigger than (size of array+1) 
  
  invalid order -> insert at end of array
  valid order   -> insert at given order
  --]]
  num_order = tonumber(order)
  if not num_order or
     num_order <= 0 or
     num_order > #rules + 1 then
   
    print("invalid order [" .. order .. "], inserting at the end")
    
    table.insert(rules, rule)
  else
    table.insert(rules, num_order, rule)
  end

  orders = generate_name_to_order(rules)

  --print for debugging 
  --[[
  for k,v in pairs(orders) do
    print(k .. " > " .. v)
  end

  print("rules size " .. #rules)
  print("rules table")
  for k,v in ipairs(rules) do
    print("order " .. k .. " name " .. v.name .. " code " .. string_dump(v.code))
  end
  --]]
end

function rules_engine.route_to (context)
  
  for i, rule in ipairs(rules) do
    print("\n\nCHECKING rule [ " .. rule.name .. " ]\n\n")
    rule_to_apply = rule.code

    setfenv(rule_to_apply, context)

    route = rule_to_apply(req)
    if (route) then
      print("\n\nMATCHED rule [ " .. rule.name .. " ]\n\n")
      print("\n\nroute is " .. route)
      return route
    else
      print("\n\nSKIPPING rule [ " .. rule.name .. " ]\n\n")
    end

  end
end

return rules_engine