cjson =                 require("cjson")
config =                require("lapis.config").get()
utils =                 require("utils")
rules_engine =          require("rules-engine")
local consul =          require("resources.roxy-consul")

local ngx = ngx
local ngx_log = ngx.log
local consul_config = config.consul
local warn = utils.warn
local notice = utils.notice

local function load_rules()

    -- everything from key/value store in consul comes back as a table 
    local rules_order = consul.get_rules_order()
    notice(rules_order)

    if not rules_order then
        warn("rule priority is not set, running without rules")
    else

        -- for each rule name (aka key) in the comma separated list of rule names
        local order = 1; 
        for rule_name in string.gmatch(rules_order, '([^,]+)') do

            local rule_value = consul.get_rule(rule_name)

            if not rule_value then
                warn("SKIPPING: rule not found for key " .. rule_name)
            else
                rules_engine.add_string_rule(rule_name, rule_value, order)
                order = order + 1
            end
        end
    end

    -- it's possible that none of the rules were found
    if utils.table_size(rules_engine.existing_rules()) == 0 then 
        warn("none of the rules from rules-order were found, running without rules")
    end
end

local _M = {}

function _M.init()
    local ok, err = ngx.timer.at(0, load_rules)
    if not ok then
        ngx_log(ngx.ERR, "failed to create timer: ", err)
    end
    warn("created timer: ", ok)
end

return _M