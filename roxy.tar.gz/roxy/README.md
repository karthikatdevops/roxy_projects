
<p align="center"><img src="doc/img/roxy-logo-2.png" width="300"/></p>
roxy is a rule-based reverse proxy server used for traffic shaping.  

>A proxy server is a server that acts as an intermediary for requests from clients seeking resources from other servers. A reverse proxy is a type of proxy server that retrieves resources on behalf of a client from one or more servers.  These resources are then returned to the client as if they originated from the proxy server itself.
><p align="left"><img src="doc/img/wikipedia-reverse-proxy.png" width="300"/></p>

roxy analyzes incoming requests and, based on request parameters matching or not matching roxy's configurable in-memory rules, proxies these requests to the defined groups of backend servers accordingly.  

The heart of roxy is an nginx+lua engine.  While nginx deals with proxying incoming requests to internal servers, returning responses to clients, and load balancing, lua is there to apply the chain of rules in prioritized order and figure out _where_ to proxy the requests. 

roxy runs inside a docker container.  Besides the nginx+lua engine, this container runs several applications needed to support ROXY's infrastructure.  There are also [external dependencies](#external-dependencies) that must be set up before roxy can run. 

# roxy dockerfile

Besides the essential build dependencies, roxy dockerfile installs several applications:

1. [consul][1] - to run consul agent in client mode ("consul client")
2. [consul-template][2]
3. [openresty][3] - nginx packaged with [LuaJIT][4], the just-in-time compiler for lua, and various useful lua libraries
4. [lapis][5] - framework for building web applications with lua; runs inside openresty
5. [supervisor][6] - to manage multiple processes inside a docker container
6. consul client and consul-template config files and lua scripts - code from roxy git repo

# rules  
## the first rule of roxy is you do not ask about roxy

Each roxy rule is a function written in lua.  This function:  
1. takes the incoming request as input  
2. applies its logic to the request, and  
3. returns one of the following:  
  * server group name where the request should be proxied.  
  * some other valid `route`, i.e. it doesn't have to be an `upstream` block that exists in the `nginx.conf` file but should still be a valid `host:port` combination.  
  * null, indicating request should be proxied to `default` server group. 

The incoming request goes through a chain of rules in order of priority, most important first.  Thus, if any rule in the chain returns a `destination` ("where to proxy it") for this request, the request breaks out of the chain of rules and gets proxied to the `destination`.  If a request goes through the whole chain of rules and no `destination` is found, it is proxied to the `default` server group.

## sample rules
All rules should fall somewhere between the *easy* and the *hard* examples below. 

### easy
A rule that just returns a `host:port` to which the request will be proxied.
```lua
return function()
    return "127.0.0.1:8080"
end
```

### hard
A rule that examines the json body of the request, extracts the account number and looks it up in memcached.  Returns the value from memcached, if it exists.  If this account does not exist in memcached, the rule will return null.
```lua
return function()
    ngx_req.read_body()

    local body, err = ngx_req.get_body_data()
    if not body then
        print("failed to get request post body: ", err)
        return
    end

    decoded_body = cjson.decode(body)

    local account = decoded_body.account
    if not account then
        print("account NOT FOUND")
    end

    print("account is " .. account)

    local memc = cache.get_memcached()
    return memc:get(string_lower(account))
end
```

# external dependencies

## consul server  

A [consul][1] agent in server mode ("consul server") is required to be up and running for roxy.  

### running a consul server docker  
Here is a sample command to run the official consul server image:
```
sudo docker run -it -h roxy-consul-server --name roxy-consul-server -p 8300:8300 -p 8301:8301 -p 8302:8302 -p 8400:8400 -p 8500:8500 -p 8301:8301/udp -p 8302:8302/udp -p 53:53/udp gliderlabs/consul-server -bootstrap -advertise [replace-with-host-ip-address] -client 0.0.0.0
```

### registering services  
Prior to starting roxy, all services (along with their healthchecks) that will make up the proxy-able server groups (i.e. [`upstream`][8] blocks in the `nginx.conf` file) need to be registered with the consul server using consul's [HTTP API][7].  Services can be added/removed once roxy is running but the `default` server group (i.e. one to proxy to if none of the rules matched) must _always_ be defined and contain least one healthy service.  
The `/v1/agent/service/register` endpoint of the HTTP API expects a JSON request body to be `PUT`. The request body must look like:
```json
{
  "id": "default-1",                                 
  "name": "default",                                    
  "tags": [
  	"default", "hello-world"
   ],
  "address": "10.251.17.150", 
  "port": 1111, 
  "enableTagOverride": false,
  "check": 
  {
    "http": "http://10.251.17.150:1111/healthCheck",
    "Interval": "10s",
    "service_id": "default-1"                           
  }
}
```
Things to note in the request above:  
1. `id` - must be unique;  
2. `name` - will become the server group name, so in order to group services together, register them with the same `name`;  
3. `check.service_id` - provide a `service_id` inside the `check` to create a *service-bound check*.  This will ensure that if the healthcheck for the service starts failing, it will only affect the availability of this specific service and **not** all other services provided by the node.  

### configuration & rules  
At startup, roxy docker container runs a script which loads roxy configuration values and existing rules into consul server's key-value store, if they don't yet exist.  Then, the container starts a consul agent client which will join the consul cluster.  Using this consul agent client, consul-template watches the key-value store changes and regenerates roxy configuration files accordingly.  

## memcached  

Rules can rely on data stored in memcached, i.e. the mappings of request parameters to server group names. An instance of memcached also needs to be up and running as roxy requires the connection parameters for it.  



  [1]: https://www.consul.io/intro/index.html                               "consul"
  [2]: https://github.com/hashicorp/consul-template                         "consul-template"
  [3]: https://openresty.org/en/                                            "openresty"
  [4]: http://luajit.org/                                                   "luajit"
  [5]: http://leafo.net/lapis/                                              "lapis"
  [6]: https://docs.docker.com/engine/admin/using_supervisord/              "supervisor"
  [7]: https://www.consul.io/docs/agent/http/catalog.html#catalog_register  "consul register service"
  [8]: http://nginx.org/en/docs/http/ngx_http_upstream_module.html#upstream "nginx upstream"
