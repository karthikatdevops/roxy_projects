#!/usr/bin/env python

# After you specify your OpenStack ENV variables, you can use this to 
# get an inventory using the nova client and looking at the servers'
# metadata.
#
# This will eventually replace the static files like qa_wcdc_b.

import logging
import os
import json

from novaclient.v1_1 import client

class OpenstackInventory:
  
  NO_SERVICE = 'NO_SERVICE'

  def get_network_name(self, os_region):
    if os_region == 'ndc_wcdc_b':
      return 'Public_AGILE'
    else:
      return 'Public_AGILE'

  # getting an ipv4 address
  def get_ipv4_address(self, server, network_name):
    if bool(server._info['addresses']):
      for addr in server._info['addresses'][network_name]:
        if addr['version'] == 4:
          return addr['addr']
    # LOG.error('Could not find address for %s', server)
    return None

  # get services
  def get_services_from_metadata(self, server):
    s = server.metadata.get('services', self.NO_SERVICE)
    return s.split(',')

  # set groups and also metadata
  def inventory(self, servers, network_name):
    # initial structure
    inv = {
      '_meta' : {
        'hostvars' : {}
      }
    }
    for server in servers:
      ipv4 = self.get_ipv4_address(server, network_name)
      # put in inv if have an ipv4 IP address
      if ipv4 is not None:
        services = self.get_services_from_metadata(server)  
        for service in services:
          inv.setdefault(service, {'hosts': []})
          inv[service]['hosts'].append(ipv4)
        # also put in metadata by IP address
        inv['_meta']['hostvars'][ipv4] = server.metadata
      
      # add nova id
      inv['_meta']['hostvars'][ipv4]['nova_id'] = server.id
    return inv
    
  def print_inventory(self):
    inv = self.get_inventory()
    print json.dumps(inv)

  def get_inventory(self):
    # log anything of WARNING priority or higher to stderr
    # (Ansible discards anything written to stderr by inventory script)
    LOG = logging.getLogger()
    LOG.addHandler(logging.StreamHandler())
    LOG.setLevel(os.getenv("DEPLOY_LOGLEVEL", "WARNING").upper())

    # require OpenStack tenant and region parameters from the environment
    os_tenant = os.getenv("OS_TENANT_NAME")
    os_region = os.getenv("OS_REGION_NAME")
    os_user = os.getenv("OS_USERNAME")
    os_pass = os.getenv("OS_PASSWORD")
    os_auth_url = os.getenv("OS_AUTH_URL")
    if not os_tenant or not os_region:
      raise Exception("OS_TENANT_NAME and OS_REGION_NAME required")

    network_name = self.get_network_name(os_region)

    # make client
    cl = client.Client(os_user, os_pass, os_tenant, os_auth_url, region_name=os_region)

    # get list of servers
    servers = cl.servers.list()
    # LOG.warning(servers)

    # convert to inventory hash
    inv = self.inventory(servers, network_name)
    LOG.warning(json.dumps(inv, sort_keys=True, indent=4, separators=(',', ': ')))
    return inv

if __name__ == '__main__':
    # test1.py executed as script
    # do something
    o = OpenstackInventory().print_inventory()