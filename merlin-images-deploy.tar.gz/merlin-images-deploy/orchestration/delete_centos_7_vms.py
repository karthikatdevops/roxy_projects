#!/bin/bash -xe

# add monitoring
ansible-playbook -i envs/${ANSIBLE_ENV}/ --vault-password-file .vault_pass.txt delete_centos7_vms.yml