#!/usr/bin/env python

import logging
import commands
import json
import argparse
import os
import os.path
import errno
import subprocess
import sys
import yaml

sys.path.append('lib')

from inventory_openstack.hosts import OpenstackInventory

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def main():
    # get ansible_env from environment
    ansible_env = os.environ['ANSIBLE_ENV']
    
    # make logs dir
    mkdir_p('orchestration/logs/adjust_nova/' + ansible_env)

    # parse args for service and desired number of VMs for this service
    parser = argparse.ArgumentParser(description='Stand up Nova VMs.')
    parser.add_argument('--percent_multiplier', type=int, default=100, help='Multiplier to env quantities')
    parser.add_argument('--force', action="store_true", help='Force to run create_ command')
    parser.add_argument('--tags', metavar='TAGS', type=str, help='Tags (e.g. sysctl)')
    parser.add_argument('--skip_tags', metavar='TAGS', type=str, default='mon', help='Skip Tags (e.g. create_vm,update_qos)')
    parser.add_argument('--limit', metavar='HOSTS', type=str, help='Hosts Filter (e.g. 96.119.147.149)')
    parser.add_argument('svc', nargs='+', metavar='SVC', type=str, help='Service (e.g. imageResizer)')
    args = parser.parse_args()
    percent_multiplier = args.percent_multiplier
    force = args.force
    tags = args.tags
    skip_tags = args.skip_tags
    limit = args.limit

    # read env_file
    env_file = 'orchestration/envs/' + ansible_env + '.yml'
    env_file_stream = open(env_file, "r")
    env_inv = yaml.load(env_file_stream)

    # get OpenStack inventory
    os_inv = OpenstackInventory().get_inventory()

    # make svcs array
    if 'ALL' in args.svc:
        svcs = env_inv.keys()
    else:
        svcs = args.svc
    
    if len(svcs) == 1:
        single_svc = True
    else:
        single_svc = False
    
    # loop through svcs and run deploy and then wait until they are all done
    procs = []
    results = []
    for svc in svcs:
        p = adjust_vms(ansible_env, os_inv, env_inv, svc, force, tags, skip_tags, limit, percent_multiplier, single_svc)
        procs.append(p)
    for p in procs:
        if single_svc:
            while p.poll() is None:
                l = p.stdout.readline()
                sys.stdout.write(l)
            print p.stdout.read()
        results.append(p.wait())

    results_strs = []
    for r in results:
        results_strs.append(str(r))
    print 'Exit codes: ' + ', '.join(results_strs)
    
    # print out logs
    if not single_svc:
        for svc in svcs:
            f_stdout = open("orchestration/logs/adjust_nova/%s/%s.txt" % (ansible_env, svc),'r')
            print "*** %s ***" % svc
            for line in f_stdout:
                sys.stdout.write(line)
            print "\n\n"

    exit(max(results))

# run command and write to logs
def run_cmd(cmd_array, ansible_env, svc, single_svc):
    if single_svc:
        # pipe to STDOUT
        f_stdout = subprocess.PIPE
    else:
        # Funnel stdout to a file object, using buffering
        f_stdout = open("orchestration/logs/adjust_nova/%s/%s.txt" % (ansible_env, svc),'w')
    
    # build ansible command and run
    d = dict(os.environ)
    print ''.join(['>>> [', svc, '] About to run: ', ' '.join(cmd_array)])
    p = subprocess.Popen(cmd_array, stdout=f_stdout, stderr=subprocess.STDOUT, bufsize=1, env=d)
    return p

# get Nova IDs from IPs
def get_nova_ids_from_ips(ips):
    s = commands.getoutput(''.join(['nova list | grep -e \'', '\|'.join(ips), '\' | sed \'s/ | .*//; s/| //;\'']))
    return s.split('\n')

# adjusting VMs and returning subprocess
def adjust_vms(ansible_env, os_inv, env_inv, svc, force, tags, skip_tags, limit, percent_multiplier, single_svc):
    # Calculate difference
    n_specified_vms = env_inv.get(svc, {}).get('quantity', 0)
    n_specified_vms = int(round(n_specified_vms * percent_multiplier / 100.0))
    os_type = env_inv.get(svc, {}).get('os_type', '')
    current_vms = os_inv.get(svc, {}).get('hosts', [])
    n_current_vms = len(current_vms)
    print 'Current ' + svc + ' VMs: ' + str(n_current_vms)

    # Calculate difference
    n_vms_to_make = n_specified_vms - n_current_vms
    if (n_vms_to_make > 0) or force:
        if os.path.isfile('create_' + os_type + '_' + svc + '.yml'):
            ans_file = 'create_' + os_type + '_' + svc + '.yml'
        else:
            ans_file = 'create_' + os_type + '_svc.yml'
        
        # make more VMs
        cmd_array = ['ansible-playbook', 
          '-i', 'envs/' + ansible_env + '/', 
          '--vault-password-file', '.vault_pass.txt', 
          ans_file,
          '-e', 'svc=' + svc,
          '-e', '@/merlin-service-versions/versions/images/fo/' + ansible_env + '.yml',
          '-e', 'nova_vms=' + str(n_vms_to_make)
        ]
        
        # add tags / skip_tags / limit
        if force:
            if limit:
                cmd_array += ['--limit', limit]
        else:
            cmd_array += ['-e', 'creating_vms=yes']
            
        if tags:
            cmd_array += ['--tags', tags]
        if skip_tags:
            cmd_array += ['--skip-tags', skip_tags]
        
        return run_cmd(cmd_array, ansible_env, svc, single_svc)
    elif n_vms_to_make < 0:
        # delete VMs
        nova_ids = get_nova_ids_from_ips(current_vms[:abs(n_vms_to_make)])
        cmd_array = ['nova', 'delete'] + nova_ids
        return run_cmd(cmd_array, ansible_env, svc, single_svc)
    else:
        # delete VMs
        cmd_array = ['echo', "Nothing to do"]
        return run_cmd(cmd_array, ansible_env, svc, single_svc)

main()

