#/bin/bash

set -xe

# see route53 ip checker for route53 rules

### create groups
neutron security-group-create coreos-group

# CDN to haproxy rules
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 68.87.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 69.241.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 69.252.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 76.96.0.0/16 coreos-group

# XRE to imageResolutionWS rules
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 96.114.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 96.115.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 96.118.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 96.119.0.0/16 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 162.150.0.0/16 coreos-group
# exists above
#neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80  --remote-ip-prefix 69.252.0.0/16 coreos-group

# general services rules
neutron security-group-rule-create  --protocol tcp --port-range-min 22 --port-range-max 22  --remote-ip-prefix 10.0.0.0/8 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 22 --port-range-max 22  --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 8000 --port-range-max 8100 --remote-ip-prefix 10.0.0.0/8 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 8000 --port-range-max 8100 --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 10.0.0.0/8 coreos-group

# consul 
neutron security-group-rule-create  --protocol tcp --port-range-min 8300 --port-range-max 8500 --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol udp --port-range-min 8300 --port-range-max 8500 --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 8500 --port-range-max 8500 --remote-ip-prefix 10.0.0.0/8 coreos-group

# myriad_bot
neutron security-group-rule-create  --protocol tcp --port-range-min 8080 --port-range-max 8080 --remote-ip-prefix 96.116.0.0/14 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 96.116.0.0/14 coreos-group

# github.comcast.com hooks for myriad_jenkins
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 69.252.79.49/32 coreos-group

# redis
neutron security-group-rule-create  --protocol tcp --port-range-min 6379 --port-range-max 6380 --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 26379 --port-range-max 26379 --remote-group-id coreos-group coreos-group

# prometheus
neutron security-group-rule-create  --protocol tcp --port-range-min 9090 --port-range-max 9090 --remote-ip-prefix 96.116.0.0/14 coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 9090 --port-range-max 9090 --remote-group-id coreos-group coreos-group
neutron security-group-rule-create  --protocol tcp --port-range-min 9090 --port-range-max 9090 --remote-ip-prefix 10.0.0.0/8 coreos-group

# perf jenkins
neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 96.119.231.83/32 coreos-group

### rules specific to envs
# imageWS/reat/max to selectors
if [[ ( $ANSIBLE_ENV == "ndc_wcdc_b" ) || ( $ANSIBLE_ENV == "ndc_as_b" ) || ( $ANSIBLE_ENV == "ndc_cmc_e") || ( $ANSIBLE_ENV == "ndc_wcdc_c") ]]; then
  # max
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.28.187.54/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.20.179.163/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.20.152.0/23 coreos-group
fi

if [[ ( $ANSIBLE_ENV == "ndc_ch2_f" ) || ( $ANSIBLE_ENV == "ndc_ho_b" ) ]]; then
  # mdbot_platform to hiera-server
  neutron security-group-rule-create  --protocol tcp --port-range-min 9090 --port-range-max 9090 --remote-ip-prefix 69.252.235.186/32 coreos-group
  # perf jenkins
  neutron security-group-rule-create  --protocol tcp --port-range-min 8001 --port-range-max 8001 --remote-ip-prefix 96.119.231.83/32 coreos-group
  # max
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.28.187.56/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.28.163.0/24 coreos-group
  # proxy (some covered by CDN to haproxy rules)
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 162.150.68.75/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 162.150.68.76/32 coreos-group
fi

if [[ ( $ANSIBLE_ENV == "gn_wcdc_c" ) || ( $ANSIBLE_ENV == "gn_as_b" ) || ( $ANSIBLE_ENV == "gn_ho_b" )  || ( $ANSIBLE_ENV == "gn_cmc_e" ) ]]; then
  # max
  neutron security-group-rule-create  --protocol tcp --port-range-min 80 --port-range-max 80 --remote-ip-prefix 172.28.77.180/32 coreos-group
fi

# s3_docker_registry
if [[ ( $ANSIBLE_ENV == "ndc_wcdc_b" ) || ( $ANSIBLE_ENV == "ndc_cmc_c" )  ]]; then
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 10.22.179.0/24 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 96.114.160.32/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.241.25.55/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.241.25.56/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.252.235.185/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.252.235.186/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.252.106.82/31 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 69.252.240.0/22 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 162.150.91.243/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 162.150.91.244/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 162.150.91.245/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 162.150.91.246/32 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 162.150.184.0/23 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 96.116.0.0/14 coreos-group
  neutron security-group-rule-create  --protocol tcp --port-range-min 443 --port-range-max 443 --remote-ip-prefix 10.0.0.0/8 coreos-group
  
fi
