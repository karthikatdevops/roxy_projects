#!/bin/bash

export ANSIBLE_HOST_KEY_CHECKING=False
export PYTHONUNBUFFERED=1

echo "Please enter the BO env: "
read -r BO_ENV
export BO_ENV=$BO_ENV

export ANSIBLE_ENV=$BO_ENV
