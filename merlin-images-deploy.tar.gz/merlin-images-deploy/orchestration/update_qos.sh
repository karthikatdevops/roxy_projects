#!/bin/bash -xe

qos=$(grep qos_id group_vars/nova-${ANSIBLE_ENV} | sed -e 's/.*: //')

for i in $(neutron port-list | grep '^| [a-z0-9]\{7\}' | sed -e 's/ | .*//; s/| //'); do neutron port-update $i --qos ${qos}; done