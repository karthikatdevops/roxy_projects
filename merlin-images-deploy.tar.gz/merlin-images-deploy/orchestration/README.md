orchestration
=============

Helper scripts one level above ansible.  These scripts will issue Ansible commands.
