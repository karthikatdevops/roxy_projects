#!/usr/bin/env python

import logging
import json
import argparse
import os
import os.path
import errno
import subprocess
import sys
import yaml

def main():
    # get ansible_env from environment
    if os.environ.get('BO_ENV', False):
        ansible_env = os.environ['BO_ENV']
        office_type = 'bo'
    elif os.environ['ANSIBLE_ENV']:
        ansible_env = os.environ['ANSIBLE_ENV']
        office_type = 'fo'

    # make logs dir
    mkdir_p('orchestration/logs/deploy/' + ansible_env)

    # parse args for service and desired number of VMs for this service
    parser = argparse.ArgumentParser(description='Deploy svc')
    parser.add_argument('--deploy_all_at_once', action="store_true", help='Deploy everything at once')
    parser.add_argument('--tags', metavar='TAGS', type=str, help='Tags (e.g. sysctl)')
    parser.add_argument('--skip_tags', metavar='TAGS', type=str, help='Skip Tags (e.g. create_vm,update_qos)')
    parser.add_argument('--limit', metavar='HOSTS', type=str, help='Hosts Filter (e.g. 96.119.147.149)')
    parser.add_argument('svc', nargs='+', metavar='SVC', type=str, help='Service (e.g. imageResizer)')
    args = parser.parse_args()

    # make svcs array
    svcs = args.svc
    tags = args.tags
    skip_tags = args.skip_tags
    limit = args.limit
    deploy_all_at_once = args.deploy_all_at_once
    
    # loop through svcs and run deploy and then wait
    procs = []
    results = []
    
    if len(svcs) == 1:
        single_svc = True
    else:
        single_svc = False
    
    for svc in svcs:
        p = run_svc_deploy(office_type, ansible_env, svc, tags, skip_tags, limit, deploy_all_at_once, single_svc)
        procs.append(p)
    for p in procs:
        if single_svc:
            while p.poll() is None:
                l = p.stdout.readline()
                sys.stdout.write(l)
            print p.stdout.read()
        results.append(p.wait())

    results_strs = []
    for r in results:
        results_strs.append(str(r))
    print 'Exit codes: ' + ', '.join(results_strs)
    
    # print out logs
    if not single_svc:
        for svc in svcs:
            f_stdout = open("orchestration/logs/deploy/%s/%s.txt" % (ansible_env, svc),'r')
            print "*** %s ***" % svc
            for line in f_stdout:
                sys.stdout.write(line)
            print "\n\n"

    exit(max(results))
    

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise


# return subprocess
def run_svc_deploy(office_type, ansible_env, svc, tags, skip_tags, limit, deploy_all_at_once, single_svc):
    if single_svc:
        # pipe to STDOUT
        f_stdout = subprocess.PIPE
        f_stderr = subprocess.PIPE
    else:
        # Funnel stdout to a file object, using line buffering
        f_stdout = open("orchestration/logs/deploy/%s/%s.txt" % (ansible_env, svc),'w',1)
        f_stderr = subprocess.STDOUT
    
    # build ansible command and run
    if os.path.isfile('deploy_' + svc + '.yml'):
        deployment_array = ['deploy_' + svc + '.yml', '-e', 'svc=' + svc]
    else:
        deployment_array = ['deploy_svc.yml', '-e', 'svc=' + svc]
    
    # add tags / skip_tags / limit
    if tags:
        deployment_array += ['--tags', tags]
    if skip_tags:
        deployment_array += ['--skip-tags', skip_tags]
    if limit:
        deployment_array += ['--limit', limit]
    if deploy_all_at_once:
        deployment_array += ['-e', 'deploy_all_at_once=yes']
    
    d = dict(os.environ)
    cmd_array = ['ansible-playbook', 
      '-i', 'envs/' + ansible_env + '/',
      '--vault-password-file', '.vault_pass.txt'] + \
      deployment_array + \
      ['-e', '@/merlin-service-versions/versions/images/' + office_type + '/' + ansible_env + '.yml'
    ]
    print '>>> About to run: ' + ' '.join(cmd_array)
    p = subprocess.Popen(cmd_array, stdout=f_stdout, stderr=f_stderr, bufsize=1, env=d)
    return p

main()

    
