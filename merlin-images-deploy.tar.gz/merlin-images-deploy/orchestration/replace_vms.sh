#!/bin/bash -xe

# to replace current VMs in a group

# check args
if [ "$#" -ne 1 ]; then
    echo "Illegal number of parameters"
fi
svc=$1

# add to_replace to existing
orchestration/add_metadata_to_nova_svc.py --svc ${svc} "services=${svc}_to_replace"

# make new ones
orchestration/adjust_nova_vms.py --percent_multiplier ${PERC_MULTIPLIER:-100} ${svc}

# prompt here
if [ $svc = "imageIndex-repeater" ] || [ $svc = "imageIndex-slave" ]; then
    echo "Not adjusting imageIndex VMs yet - stopping here for now"
    exit 1
fi

# deploy to new ones
orchestration/deploy_svc.py ${svc} --deploy_all_at_once

# adjust old group
orchestration/add_metadata_to_nova_svc.py --svc ${svc}_to_replace "services=centos7_to_delete"

# delete old group
orchestration/delete_centos_7_vms.py

