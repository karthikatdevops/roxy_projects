#!/bin/bash

export ANSIBLE_HOST_KEY_CHECKING=False
export PYTHONUNBUFFERED=1

export OS_AUTH_URL=https://keystone.ece.comcast.net:5000/v2.0

echo "Please enter the Ansible env: "
read -r ANSIBLE_ENV
export ANSIBLE_ENV=$ANSIBLE_ENV

# set OS_REGION_NAME
if [[ $ANSIBLE_ENV == "gn_wcdc_c" ]]; then 
  export OS_REGION_NAME=ndc_wcdc_c
  export GN_ENV=yes
elif [[ $ANSIBLE_ENV == "gn_as_b" ]]; then 
  export OS_REGION_NAME=ndc_as_b
  export GN_ENV=yes
elif [[ $ANSIBLE_ENV == "gn_ho_b" ]]; then 
  export OS_REGION_NAME=ndc_ho_b
  export GN_ENV=yes
elif [[ $ANSIBLE_ENV == "gn_cmc_e" ]]; then
  export OS_REGION_NAME=ndc_cmc_e
  export GN_ENV=yes
else
  export OS_REGION_NAME=$ANSIBLE_ENV
  export GN_ENV=no
fi

if [[ $GN_ENV == "yes" ]]; then
  export OS_TENANT_ID=e0f33327a2a64c6a8a5826685d5527d3
  export OS_TENANT_NAME="Merlin Images Gracenote"
else
  export OS_TENANT_ID=e13684552a564e26b98cdb8e6cdece2d
  export OS_TENANT_NAME="Merlin Images"
fi

echo "Please enter your OpenStack Username: "
read -r OS_USERNAME
export OS_USERNAME=$OS_USERNAME

# With Keystone you pass the keystone password.
echo "Please enter your OpenStack Password: "
read -sr OS_PASSWORD_INPUT
export OS_PASSWORD=$OS_PASSWORD_INPUT
