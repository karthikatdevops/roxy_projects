#!/usr/bin/env python

import logging
import commands
import json
import argparse
import os
import os.path
import errno
import subprocess
import sys
import yaml

sys.path.append('lib')

from inventory_openstack.hosts import OpenstackInventory

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def main():
    # get ansible_env from environment
    ansible_env = os.environ['ANSIBLE_ENV']

    # parse args for service and desired number of VMs for this service
    parser = argparse.ArgumentParser(description='Stand up Nova VMs.')
    parser.add_argument('--svc', metavar='SVC', type=str, help='Service (e.g. imageResizer)')
    parser.add_argument('--ips', metavar='IPS', type=str, help='IP address separated by commas (e.g. 96.119.179.244,96.119.179.245)')
    parser.add_argument('metadata', metavar='METADATA', type=str, help='Metadata (e.g. services=imageResizer,imageResizer_to_replace)')
    args = parser.parse_args()
    svc = args.svc
    if args.ips:
        ips = args.ips.split(',')
    else:
        ips = None
    metadata = args.metadata

    # get OpenStack inventory
    os_inv = OpenstackInventory().get_inventory()
    
    # find servers
    if ips:
        current_vms = ips
    else:
        current_vms = os_inv.get(svc, {}).get('hosts', [])
    nova_ids = get_nova_ids_from_ips(current_vms)
    
    for nova_id in nova_ids:
        add_metadata(nova_id, metadata)

# run command and write to logs
def add_metadata(nova_id, metadata):
    # build nova command and run
    cmd_array = ['nova', 'meta', nova_id, 'set', metadata]
    d = dict(os.environ)
    print ''.join(['>>> About to run: ', ' '.join(cmd_array)])
    p = subprocess.Popen(cmd_array, bufsize=1, env=d)
    exit_code = p.wait()
    print 'Exit code: ' + str(exit_code)

# get Nova IDs from IPs
def get_nova_ids_from_ips(ips):
    s = commands.getoutput(''.join(['nova list | grep -e \'', '\|'.join(ips), '\' | sed \'s/ | .*//; s/| //;\'']))
    return s.split('\n')

main()

