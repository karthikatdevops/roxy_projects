#!/bin/bash -xe

# add monitoring
ansible-playbook -i envs/${ANSIBLE_ENV}/ --vault-password-file .vault_pass.txt add_monitoring.yml -e svc=$1 --tags mon