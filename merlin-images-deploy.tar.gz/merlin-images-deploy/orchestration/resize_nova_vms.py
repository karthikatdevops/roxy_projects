#!/usr/bin/env python

import logging
import json
import argparse
import os
import os.path
import errno
import subprocess
import sys
import yaml

sys.path.append('lib')
from inventory_openstack.hosts import OpenstackInventory

def main():
    # get ansible_env from environment
    if os.environ.get('BO_ENV', False):
        ansible_env = os.environ['BO_ENV']
        office_type = 'bo'
    elif os.environ['ANSIBLE_ENV']:
        ansible_env = os.environ['ANSIBLE_ENV']
        office_type = 'fo'

    # make logs dir
    mkdir_p('orchestration/logs/resize/' + ansible_env)

    # parse args for service and desired number of VMs for this service
    parser = argparse.ArgumentParser(description='Deploy svc')
    parser.add_argument('--limit', metavar='HOSTS', type=str, help='Hosts Filter (e.g. 96.119.147.149)')
    parser.add_argument('svc', nargs=1, metavar='SVC', type=str, help='Service (e.g. imageResizer)')
    args = parser.parse_args()

    # make svcs array
    svc = args.svc[0]
    limit = args.limit
    
    # get OS inventory
    os_inv = OpenstackInventory().get_inventory()
    hosts = os_inv.get(svc, {}).get('hosts', [])
    
    if limit:
        hosts = list(set(hosts) & set(limit.split(',')))
    
    # loop through hosts and run resizes
    for host in hosts:
        p = run_resize_cmds(office_type, ansible_env, svc, host)

    print 'done!'

def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise


# return exit code
def run_resize_cmds(office_type, ansible_env, svc, host):
    resize_array = []
    
    cmd_array = ['ansible-playbook', 
      '-i', 'envs/' + ansible_env + '/',
      '--vault-password-file', '.vault_pass.txt',
      'resize_nova_centos7_vms.yml', '--limit', host,
      '-e', 'svc=' + svc,
      '-e', '@/merlin-service-versions/versions/images/' + office_type + '/' + ansible_env + '.yml'
    ]
    run_cmd(cmd_array + ['--tags', 'consul_disable,nova_resize_vm'])
    run_cmd(['sleep', '30'])
    run_cmd(cmd_array + ['--skip-tags', 'consul_disable,nova_resize_vm'])
   
def run_cmd(cmd_array):
    # pipe to STDOUT
    f_stdout = subprocess.PIPE
    f_stderr = subprocess.PIPE
    
    d = dict(os.environ)
    
    print '>>> About to run: ' + ' '.join(cmd_array)
    p = subprocess.Popen(cmd_array, stdout=f_stdout, stderr=f_stderr, bufsize=1, env=d)

    while p.poll() is None:
        l = p.stdout.readline()
        sys.stdout.write(l)
    print p.stdout.read()
    res = p.wait()

    if res != 0:
        raise Exception('Non-zero exit code')
    
main()

    
