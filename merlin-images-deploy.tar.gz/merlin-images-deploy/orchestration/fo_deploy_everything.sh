#!/bin/bash -xe

orchestration/deploy_svc.py imageIndex-repeater mezzStore

orchestration/deploy_svc.py imageIndex-slave imageResizer imageDownloaderService imageCacheInvalidatorService

orchestration/deploy_svc.py imageSelectorWebService
