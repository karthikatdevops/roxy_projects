#!/bin/bash

export ANSIBLE_HOST_KEY_CHECKING=False

export EC2_URL=ec2.us-east-1.amazonaws.com
export AWS_REGION=us-east-1

echo "Please enter your AWS Access Key: "
read -r AWS_ACCESS_KEY
export AWS_ACCESS_KEY=$AWS_ACCESS_KEY
export AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY

echo "Please enter your AWS Secret Key: "
read -sr AWS_SECRET_KEY
export AWS_SECRET_KEY=$AWS_SECRET_KEY
export AWS_SECRET_ACCESS_KEY=$AWS_SECRET_KEY