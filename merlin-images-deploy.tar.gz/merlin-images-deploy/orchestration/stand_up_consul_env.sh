#!/bin/bash -xe

# add security rules
# NOTE: These first two steps only need to be run if no security rules or keys are present in the tenant:
#orchestration/add_consul_security_rules.sh

# add nova key
#nova keypair-add --pub_key ~/.ssh/id_dsa.pub mideploy

# stand up jenkins
orchestration/adjust_nova_vms.py myriad_jenkins
orchestration/deploy_svc.py myriad_jenkins --tags myriad_jenkins

# Once jenkins is up on port 8080, run merlin-service-versions and merlin-images-deploy jobs to check out repos.
orchestration/deploy_svc.py myriad_jenkins --tags vault_pass

### from Jenkins, run the following Jobs:
# 1. Adjust_nova_vms "ALL",
# 1a. Once all VMs are up, adjust downloader_to_mezzstore in group_vars/<env>
# 1b. Re-run merlin-images-deploy to get fresh downloader config
# 2. Deploy_everything (runs the following)
## Deploy_svc "consul-primary"
## Deploy_svc "consul-secondary"
## Deploy_redis_cluster
## Deploy_entredis_cluster
## Deploy_FO
## Deploy_svc "env_haproxy consul_prometheusHub"
## Update_aws_rules
## Add_monitoring
# 3. Deploy_svc "resredis-master"
# 4. Deploy_svc "resredis-slave"
# 5. Deploy_svc "resredis-sentinel"
# 6. Deploy_svc "env_haproxy-resolution"

# for Items 3-5 above, we could adjust the Deploy_everything job to include them.

# Wait for imageIndex to finish replicating

# Kick off a bulk entity job
# Kick off a mezz store bootstrap job

# Manually add DNS for r53 to env_haproxy

# Check prometheus alerts

# Turn on prometheus alertmanager - orchestration/deploy_svc.py consul_prometheusHub --tags prom_alertmanager
