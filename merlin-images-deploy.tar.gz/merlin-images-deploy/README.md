merlin-images-deploy
====================

Ansible deployment code for Merlin Images services.

# Docker Setup (Recommended)
* On Mac OS, you can use kitematic
* git clone this repository
* ensure private keys are in private/.ssh:

        id_dsa: for OpenStack envs
        chaz/id_dsa: for CHAZ envs
        mer/id_dsa: for PO and BR envs

* ensure merlin-service-versions is checked out on the same level as merlin-images-deploy
* build docker image:

        $ docker build -t mid .

* mount directory over it and run docker container:

        $ ./launch_docker_container.sh

* cd into /merlin-images-deploy to run ansible tasks
* ensure you have the vault password file (./vault_pass.txt)

# Non-Docker Setup
* Install the python nova and neutron clients, or you won't be able to create VMs
* Have your ssh keys and config set up (~/.ssh/config)
* [Install ansible](http://docs.ansible.com/intro_installation.html) on your machine
* git clone this repository
* install requirements

        $ ansible-galaxy install -r requirements.txt

* ensure you have the vault password file (./vault_pass.txt)

# Running Tasks

## Create and deploy imageIndex repeaters in Front Office

    # set env vars for OpenStack (e.g. ndc_cmc_e)
    $ . orchestration/set_os_creds.sh

    # adjust orchestration/envs/<env>.yml first
    $ orchestration/adjust_nova_vms.py imageIndex-repeater
    
    # deploy svc
    $ orchestration/deploy_svc.py imageIndex-repeater

## Deploy redis in Back Office

    # set env vars for back office (e.g. merch2cImages)
    $ . orchestration/set_bo_creds.sh

    # deploy master
    $ orchestration/deploy_svc.py redis-master
    
    # deploy slave
    $ orchestration/deploy_svc.py redis-slave
    
    # deploy sentiel
    $ orchestration/deploy_svc.py redis-sentinel

## Deploy imagePerfJenkins to Front Office HO-B

    # set env vars for OpenStack
    $ . orchestration/set_os_creds.sh
    
    # create and deploy svc
    $ ansible-playbook -i envs/ndc_ho_b/ --vault-password-file .vault_pass.txt create_ubuntu_imagePerfJenkins.yml -e svc=imagePerfJenkins -e @/merlin-service-versions/versions/images/fo/ndc_ho_b.yml -e nova_vms=1 -e creating_vms=yes -e dev_name=/dev/vdc

# Misc
## Notes
* Ad-hoc commands are not working well b/c group_vars/ is not in the same folders as the inventory files.
* Docker does not play well w/ symbolic links so there's no quick fix for this.

## Helpful Links
* [Managing CoreOS with Ansible](https://coreos.com/blog/managing-coreos-with-ansible/)
* [Merlin Images - Deployment Notes](http://teamcompass.cable.comcast.com/x/6balAQ)
*
