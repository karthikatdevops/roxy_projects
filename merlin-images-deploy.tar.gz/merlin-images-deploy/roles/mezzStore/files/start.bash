#! /bin/bash
set -eu

touch /opt/trafficserver/var/log/trafficserver/diags.log
touch /opt/trafficserver/var/log/trafficserver/squid.log

tail --pid $$ -F /opt/trafficserver/var/log/trafficserver/diags.log | awk '{ print strftime("%Y-%m-%d %T,000") " s=mezz_diags", $0; fflush() }' &
tail --pid $$ -F /opt/trafficserver/var/log/trafficserver/squid.log | awk '{ print strftime("%Y-%m-%d %T,000") " s=mezz_squid", $0; fflush() }' &

exec /opt/trafficserver/bin/traffic_cop
