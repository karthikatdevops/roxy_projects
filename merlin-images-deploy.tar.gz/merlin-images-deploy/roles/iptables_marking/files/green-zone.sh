#!/bin/sh

## USAGE: green-zone.sh [ enable | disable | status ]
## This script only applies the CS2 mark to packets using ${IPTABLES}.
## If you need to apply other marks in addition to CS2, you will
## need to modify the ${IPTABLES} rules appropriately.

## VARS
IPTABLES=/sbin/iptables

if [ $# -gt 0 ]; then
    if [ "$1" = "enable" ]; then
        ${IPTABLES} -t mangle --flush
        ${IPTABLES} -t mangle -A OUTPUT -p icmp -j DSCP --set-dscp 16
        ${IPTABLES} -t mangle -A OUTPUT -p tcp -j DSCP --set-dscp 16
        ${IPTABLES} -t mangle -A OUTPUT -p udp -j DSCP --set-dscp 16
        ${IPTABLES} -t mangle -nL
        exit 0
    fi
    if [ "$1" = "disable" ]; then
        ${IPTABLES} -t mangle --flush
        ${IPTABLES} -t mangle -nL
        exit 0
    fi
    if [ "$1" = "status" ]; then
        COUNT=`${IPTABLES} -t mangle -nL | egrep -c '^DSCP.*(icmp|tcp|udp).*set 0x10 *$'`
        if [ $COUNT -eq 0 ]; then
            echo "Green Zone: disabled"
            exit 0
        fi
        if [ $COUNT -lt 3 ]; then
            echo "Green Zone: partially enabled - PLEASE REVIEW"
            exit 0
        fi
        echo "Green Zone: enabled"
        exit 0
    fi
fi

echo "Usage: $0 [ enable | disable | status ]"
exit 1
