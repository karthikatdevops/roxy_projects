#!/usr/bin/env python

import os
import sys

sys.path.append('lib')

from inventory_openstack.hosts import OpenstackInventory

# set env variables for openstack:
if os.getenv("OS_REGION_NAME") != "ndc_ho_b":
  raise ValueError('OS_REGION_NAME should be set to ndc_ho_b')

OpenstackInventory().print_inventory()
