#/bin/bash
docker run -it --rm --dns 69.252.80.80 -v `pwd`/../merlin-service-versions:/merlin-service-versions -v `pwd`:/merlin-images-deploy -v `pwd`/private/.ssh/:/root/.ssh/ mid