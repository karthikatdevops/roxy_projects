# roxy-consul-server

<img style="float: right" src="doc/img/roxy-consul-server-dockerfile.png"  width="200">   

Dockerfile contained here is used to create a docker image that  
1. starts consul server   
2. runs a bash script to load roxy config and rules into consul's key/value store

## building the docker image

From the directory where Dockerfile is located, run:

```sh
$ docker build -t roxy-consul-server .
```   

Note that `-t` is used to name the image, and `.` is the path to the build context for the dockerfile.  Output will look similar to:

```dockerfile 
Sending build context to Docker daemon 172.5 kB
Step 1 : FROM ubuntu:16.04
 ---> 44f18eb3c13f
Step 2 : RUN apt-get update  && apt-get install -y     build-essential  	tree     vim     curl     unzip     openssh-server     apache2     supervisor  && apt-get clean
 ---> Using cache
 ---> 07b20a961b58

... ... ...

Step 15 : CMD /usr/bin/supervisord
 ---> Using cache
 ---> cadab879bd89
Successfully built cadab879bd89
```

Once the build process completes, run:

```console 
$ docker images
```

The new image is now listed:

```console
REPOSITORY           TAG                 IMAGE ID            CREATED             VIRTUAL SIZE
roxy-consul-server   latest              5e90d9ebc660        9 seconds ago       538.4 MB
```

## running the docker container ##

#### prerequisites ####
There are some things that you will need to know to run the container correctly.  It's a good idea to collect these gems before you try running it.  

1. `host-ip-address` - this ip is what ultimately be advertised as the ip of consul that all consul clients will `-join`; should usually be the ip of the docker host.
2. `rules` - to load rules into consul's key/value store, the directory with rules needs to be mounted to a directory inside the docker container.  In the `docker run` command, provide the absolute path to the host `rules` directory and mount to `/opt/app/roxy/rules` in the container.  For more details, refer to the rule writing guide.
3. `docker-bridge-network-ip-address` - to get this value, run:    

``` 
$ sudo docker network inspect bridge   
```

Use the ip address from the `subnet` property.  In the example below, this would be `172.17.0.0`:

```json
[
    {
        "Name": "bridge",
        "Id": "49ae4198d008a4f0ceceaef9b52884068934528c68ab6a3aacb31996aedf2aa6",
        "Scope": "local",
        "Driver": "bridge",
        "IPAM": {
            "Driver": "default",
            "Config": [
                {
                    "Subnet": "172.17.0.0/16"
                }
            ]
        },
        "Containers": {},
        "Options": {
            "com.docker.network.bridge.default_bridge": "true",
            "com.docker.network.bridge.enable_icc": "true",
            "com.docker.network.bridge.enable_ip_masquerade": "true",
            "com.docker.network.bridge.host_binding_ipv4": "0.0.0.0",
            "com.docker.network.bridge.name": "docker0",
            "com.docker.network.driver.mtu": "1500"
        }
    }
]
```  

### Run, docker, RUN!!! ###

Execute the `docker run` command below replacing the following values with names you come up with and values you've collected [here](#prerequisites):  

1. `docker-container-name`  
2. `host-ip-address`   
3. `host-name`   
4. `docker-bridge-network-ip-address`  
5. `/absolute/path/to/host/rules/directory`  
6. `docker-image-name` 

```
$ docker run -itd \
--name docker-container-name \
-e consul_advertise_ip=host-ip-address \
-h host-name \
-p 8300:8300 \
-p 8301:8301 \
-p 8301:8301/udp \
-p 8302:8302 \
-p 8302:8302/udp \
-p 8400:8400 \
-p 8500:8500 \
-p docker-bridge-network-ip-address:53:53 \
-p docker-bridge-network-ip-address:53:53/udp \
-v /absolute/path/to/host/rules/directory:/opt/app/roxy/rules \
docker-image-name
```

Below is a quick explanation of options used in the above `docker run` command:
* `-itd`
    * `-i` Keep STDIN open even if not attached
    * `-t` Allocate a pseudo-TTY
    * `-d` Run container in background and print container ID  
    
* `-h` Container host name. Setting the container hostname is the intended way to name the Consul Agent node; the host name can be used         to query consul's nodes' healthcheck and other endpoints.
* `-p` Publish a container's ports to the host.  All the ports listed in the `docker run` command must be mapped in order for consul agent server to run properly. Use `docker-bridge-network-ip-address` from [prerequisites](#prerequisites).  
* `-v` Bind mount a volume.  Used to mount the host `rules` directory into the container at `/opt/app/roxy/rules`.  
* `-e` Set environment variables.  Use the value for `host-ip-address` that you've [hunted down earlier](#prerequisites).

Once you execute the command, you should see a container id.  For example, running:

```
$ docker run -itd \
--name roxy \
-e consul_advertise_ip=192.168.99.100 \
-h roxy-host \
-p 8300:8300 \
-p 8301:8301 \
-p 8301:8301/udp \
-p 8302:8302 \
-p 8302:8302/udp \
-p 8400:8400 \
-p 8500:8500 \
-p 172.17.0.0:53:53 \
-p 172.17.0.0:53:53/udp \
-v /Documents/code/roxy/rules:/opt/app/roxy/rules \
roxy-consul-server
```

outputs the following container id:

```
16bda28d717fcf5e84819bdae51c44416ca4e28e674fb530d34cb2233527646a      <-- this is the container id
```
You should now be able to run `docker ps -a` and see this container running.

## What have you done? ##

You may be wondering what exactly happens inside the container when you run `docker run`. 

### use of supervisord ###

Since this container runs multiple processes (consul and script), it uses [supervisor](https://docs.docker.com/engine/admin/using_supervisord/) to better control these processes.  When the container is started, supervisor runs the processes defined in the `supervisord.conf` file: starts a consul server and runs a script to load values into consul's key/value store.  

### consul server ###

The consul server installation and startup options mimic those of the [gliderlabs consul dockerimage](https://github.com/gliderlabs/docker-consul/tree/master/0.6), previously knows as the [progrium/consul image](https://hub.docker.com/r/progrium/consul/).

Dockerfile installs `consul 0.6.4` and starts it in bootstrap server mode (TODO? make version of consul installed configurable from `docker run`?)

### loading script ###
The loading script loads rules and default config properties for roxy's nginx.conf.  It waits for consul server to elect the cluster leader, and then starts saving values to the key/value store.

#### config properties for roxy's nginx.conf ####
Below are the nginx properties loaded by the script.  They are eventually used by consul-template to generate the `nginx.conf` file for roxy.  New properties can be added but note that, in case of changes, `nginx.ctmpl` template file used by consul-template also needs to be updated.   

```properties
roxy/ars/nginx/num-workers=2
roxy/ars/nginx/error-log-level=notice
roxy/ars/nginx/worker-connections=1024
roxy/ars/nginx/access-log=logs/access.log main
roxy/ars/nginx/listen-port=8080
roxy/ars/nginx/lua-code-cache=on
roxy/ars/nginx/lua-need-request-body=on
roxy/ars/nginx/sendfile=on
roxy/ars/nginx/tcp-nopush=on
roxy/ars/nginx/tcp-nodelay=on
roxy/ars/nginx/proxy-buffering=on
roxy/ars/nginx/buffer-size=128k
roxy/ars/nginx/buffers=100 128k
```

#### rules ####
Sample structure of the host `rules` directory: 

```
.
├── account.lua                 <--- this is a rule 
├── clientprofile.lua           <--- this is a rule 
├── new_rule.lua                <--- this is a rule 
├── schema-1_7.lua              <--- this is a rules config file
└── rules-priority.properties   <--- this is a rule 
```

Some rules about the `rules`:
* each rule is stored in a separate file
* this file must be named after the rule
    * If the rule is called `account`, the file should be called `account.lua`
    * Let's do another one: if the rule is called `clientprofile`, the file should be called `clientprofile.lua`
    * This is important.  That's why we did 2 examples.
* the `rules-priority.properties` file 
    * *must* be named `rules-priority.properties` since the container will look for it by name
    * outlines the priority of rules, so rules should be listed in prioritized order, most important first.
    * the rules directory from host will be mounted to `/opt/app/roxy/rules` location inside the container.  What this means is whatever       rules exist on the host in the rules directory, to the docker container it will look like they are located in `/opt/app/roxy/rules`       directory.  Therefore, inside the `rules-priority.properties` file, the absolute path to the file with the rule *must* start with        `/opt/app/roxy/rules` followed by whatever the file name is.  For example,  
    
```properties
new_rule=/opt/app/roxy/rules/new_rule.lua                  <--- this is the most important rule
account=/opt/app/roxy/rules/account.lua
clientprofile=/opt/app/roxy/rules/clientprofile.lua
schema-1_7=/opt/app/roxy/rules/schema-1_7.lua              <--- this is the least important rule
```

Based on this file, the `/roxy/ars/rules_priority` key in consul will be set to `new_rule, account, clientprofile, schema-1_7`
